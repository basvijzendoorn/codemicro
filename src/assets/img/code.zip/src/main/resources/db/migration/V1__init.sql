CREATE TABLE first_table(
    id SERIAL PRIMARY KEY,
    title VARCHAR(1024)
);
CREATE TABLE second_table(
    id SERIAL PRIMARY KEY,
    age BIGINT
);